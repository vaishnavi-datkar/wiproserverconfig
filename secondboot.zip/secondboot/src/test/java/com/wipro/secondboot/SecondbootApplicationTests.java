package com.wipro.secondboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
