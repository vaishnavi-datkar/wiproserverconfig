package com.wipro.secondboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondbootApplication.class, args);
	}

}
