package com.wipro.cityapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityappApplicationTests {

	@Test
	void contextLoads() {
	}

}
