package com.wipro.cityapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CityappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CityappApplication.class, args);
	}

}
