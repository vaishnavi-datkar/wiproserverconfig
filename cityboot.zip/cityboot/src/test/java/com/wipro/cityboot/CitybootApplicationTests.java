package com.wipro.cityboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitybootApplicationTests {

	@Test
	void contextLoads() {
	}

}
